INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=01 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	4);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	5);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	12);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	14);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	20);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	37);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	52);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	96);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	155);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	269);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	330);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	464);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	645);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	1339);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	2468);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	4408);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	6211);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	9045);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	12305);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	14905);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	20011);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	23112);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	25399);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	30766);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	33768);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	38087);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	43139);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=01 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	47440);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	51810);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	57160);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	63307);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	67552);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	72181);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	76876);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	81803);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	87028);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	92384);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	98308);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	103208);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	106764);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	110465);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	118302);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	123146);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	127352);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	131273);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	134446);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	136816);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	139335);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	142442);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	145855);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	150484);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	155124);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	158268);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='New York City' ),
	'USA',
	160499);
