INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	8);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	8);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	13);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	23);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	43);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	77);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	101);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	124);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	170);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	228);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	277);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	365);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	489);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	653);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	869);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	1121);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	1471);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	1700);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	2123);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=01 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	2415);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	2885);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	3363);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	3889);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	4145);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	4670);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	5125);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	5460);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	5897);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	6299);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	6757);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	7057);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	7458);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	7711);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	8066);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	8325);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	8823);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	9044);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	9353);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	9656);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	10055);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	10152);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	10587);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	10925);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	11004);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	11350);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Miami' ),
	'USA',
	11569);
