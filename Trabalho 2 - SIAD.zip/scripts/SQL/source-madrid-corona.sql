INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	4);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	5);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	8);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	10);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	29);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	49);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	70);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	90);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	137);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	174);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	202);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	469);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	782);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	1024);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	1388);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	1990);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	2940);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	3544);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	4165);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	4871);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	5637);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	6777);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	7165);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	8921);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	9702);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	10575);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	12352);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	14597);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	17166);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	19243);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	21520);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	22677);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	24090);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	27509);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	29840);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	32155);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	34188);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	36249);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	37584);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	38723);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	40469);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	42450);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	43877);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	44783);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	45849);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	46587);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	47146);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	48048);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	49526);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	50694);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	51993);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	52946);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	54884);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	56963);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	57997);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	59199);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	60487);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	61726);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	62510);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	62817);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	63443);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Madrid' ),
	'ESP',
	63989);
