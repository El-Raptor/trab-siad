INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	3);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	3);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	5);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	5);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	7);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	7);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	7);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	10);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	10);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	10);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	16);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	22);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	28);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	36);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	42);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	47);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	58);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	62);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	66);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	69);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	69);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=01 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	71);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	74);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	80);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	82);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	81);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	85);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	88);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	97);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	106);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	111);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	123);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	133);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	144);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	151);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	168);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	170);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	182);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	187);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	192);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	197);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	202);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	203);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	207);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	207);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	209);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	210);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	214);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Canberra' ),
	'AUS',
	217);
