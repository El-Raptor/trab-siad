INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	6);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	7);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	9);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	10);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	11);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	12);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	15);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	17);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	26);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	32);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	37);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	40);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	53);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	67);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	80);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	113);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	127);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	141);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	174);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	211);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	262);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	285);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	304);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	338);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	366);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	387);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=01 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	399);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	440);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	472);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	520);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	564);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	588);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	622);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	648);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	674);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	708);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	749);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	772);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	785);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	806);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	841);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	863);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	880);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	905);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	919);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	954);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1001);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1044);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1095);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1202);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1260);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1303);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Buenos Aires' ),
	'ARG',
	1347);
