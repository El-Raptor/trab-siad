--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.0

-- Started on 2020-05-27 18:39:48

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 7 (class 2615 OID 16787)
-- Name: coronavirus; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA coronavirus;


ALTER SCHEMA coronavirus OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 215 (class 1259 OID 17027)
-- Name: casos_por_cidade; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.casos_por_cidade (
    id integer NOT NULL,
    id_data integer NOT NULL,
    cidade integer NOT NULL,
    pais character(3) NOT NULL,
    casos integer
);


ALTER TABLE coronavirus.casos_por_cidade OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 17025)
-- Name: casos_por_cidade_id_seq; Type: SEQUENCE; Schema: coronavirus; Owner: postgres
--

CREATE SEQUENCE coronavirus.casos_por_cidade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coronavirus.casos_por_cidade_id_seq OWNER TO postgres;

--
-- TOC entry 2911 (class 0 OID 0)
-- Dependencies: 214
-- Name: casos_por_cidade_id_seq; Type: SEQUENCE OWNED BY; Schema: coronavirus; Owner: postgres
--

ALTER SEQUENCE coronavirus.casos_por_cidade_id_seq OWNED BY coronavirus.casos_por_cidade.id;


--
-- TOC entry 206 (class 1259 OID 16887)
-- Name: cidade; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.cidade (
    id integer NOT NULL,
    nome text NOT NULL
);


ALTER TABLE coronavirus.cidade OWNER TO postgres;

--
-- TOC entry 205 (class 1259 OID 16885)
-- Name: cidade_id_seq; Type: SEQUENCE; Schema: coronavirus; Owner: postgres
--

CREATE SEQUENCE coronavirus.cidade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coronavirus.cidade_id_seq OWNER TO postgres;

--
-- TOC entry 2912 (class 0 OID 0)
-- Dependencies: 205
-- Name: cidade_id_seq; Type: SEQUENCE OWNED BY; Schema: coronavirus; Owner: postgres
--

ALTER SEQUENCE coronavirus.cidade_id_seq OWNED BY coronavirus.cidade.id;


--
-- TOC entry 213 (class 1259 OID 16927)
-- Name: covid19_mundo; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.covid19_mundo (
    id integer NOT NULL,
    data_reg integer NOT NULL,
    casos integer NOT NULL,
    mortes integer NOT NULL,
    pais_cod character(3) NOT NULL,
    total_leitos integer NOT NULL
);


ALTER TABLE coronavirus.covid19_mundo OWNER TO postgres;

--
-- TOC entry 212 (class 1259 OID 16925)
-- Name: covid19_mundo_id_seq; Type: SEQUENCE; Schema: coronavirus; Owner: postgres
--

CREATE SEQUENCE coronavirus.covid19_mundo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coronavirus.covid19_mundo_id_seq OWNER TO postgres;

--
-- TOC entry 2913 (class 0 OID 0)
-- Dependencies: 212
-- Name: covid19_mundo_id_seq; Type: SEQUENCE OWNED BY; Schema: coronavirus; Owner: postgres
--

ALTER SEQUENCE coronavirus.covid19_mundo_id_seq OWNED BY coronavirus.covid19_mundo.id;


--
-- TOC entry 209 (class 1259 OID 16906)
-- Name: leitos; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.leitos (
    id integer NOT NULL,
    total_leitos integer NOT NULL,
    pais_iso character(3) NOT NULL
);


ALTER TABLE coronavirus.leitos OWNER TO postgres;

--
-- TOC entry 208 (class 1259 OID 16904)
-- Name: leitos_id_seq; Type: SEQUENCE; Schema: coronavirus; Owner: postgres
--

CREATE SEQUENCE coronavirus.leitos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coronavirus.leitos_id_seq OWNER TO postgres;

--
-- TOC entry 2914 (class 0 OID 0)
-- Dependencies: 208
-- Name: leitos_id_seq; Type: SEQUENCE OWNED BY; Schema: coronavirus; Owner: postgres
--

ALTER SEQUENCE coronavirus.leitos_id_seq OWNED BY coronavirus.leitos.id;


--
-- TOC entry 207 (class 1259 OID 16896)
-- Name: pais; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.pais (
    codigo_iso character(3) NOT NULL,
    nome text NOT NULL,
    pop integer NOT NULL,
    continente character varying(20) NOT NULL
);


ALTER TABLE coronavirus.pais OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 16879)
-- Name: temperatura; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.temperatura (
    id integer NOT NULL,
    temp_celsius integer NOT NULL
);


ALTER TABLE coronavirus.temperatura OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 17048)
-- Name: temperatura_cidade; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.temperatura_cidade (
    id_data integer NOT NULL,
    temp_max integer NOT NULL,
    temp_min integer NOT NULL,
    cidade integer NOT NULL,
    pais character(3) NOT NULL,
    id integer NOT NULL
);


ALTER TABLE coronavirus.temperatura_cidade OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 17076)
-- Name: temperatura_cidade_id_seq; Type: SEQUENCE; Schema: coronavirus; Owner: postgres
--

CREATE SEQUENCE coronavirus.temperatura_cidade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coronavirus.temperatura_cidade_id_seq OWNER TO postgres;

--
-- TOC entry 2915 (class 0 OID 0)
-- Dependencies: 217
-- Name: temperatura_cidade_id_seq; Type: SEQUENCE OWNED BY; Schema: coronavirus; Owner: postgres
--

ALTER SEQUENCE coronavirus.temperatura_cidade_id_seq OWNED BY coronavirus.temperatura_cidade.id;


--
-- TOC entry 203 (class 1259 OID 16877)
-- Name: temperatura_id_seq; Type: SEQUENCE; Schema: coronavirus; Owner: postgres
--

CREATE SEQUENCE coronavirus.temperatura_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coronavirus.temperatura_id_seq OWNER TO postgres;

--
-- TOC entry 2916 (class 0 OID 0)
-- Dependencies: 203
-- Name: temperatura_id_seq; Type: SEQUENCE OWNED BY; Schema: coronavirus; Owner: postgres
--

ALTER SEQUENCE coronavirus.temperatura_id_seq OWNED BY coronavirus.temperatura.id;


--
-- TOC entry 211 (class 1259 OID 16919)
-- Name: tempo; Type: TABLE; Schema: coronavirus; Owner: postgres
--

CREATE TABLE coronavirus.tempo (
    id integer NOT NULL,
    dia smallint NOT NULL,
    mes smallint NOT NULL,
    ano smallint NOT NULL
);


ALTER TABLE coronavirus.tempo OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 16917)
-- Name: tempo_id_seq; Type: SEQUENCE; Schema: coronavirus; Owner: postgres
--

CREATE SEQUENCE coronavirus.tempo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE coronavirus.tempo_id_seq OWNER TO postgres;

--
-- TOC entry 2917 (class 0 OID 0)
-- Dependencies: 210
-- Name: tempo_id_seq; Type: SEQUENCE OWNED BY; Schema: coronavirus; Owner: postgres
--

ALTER SEQUENCE coronavirus.tempo_id_seq OWNED BY coronavirus.tempo.id;


--
-- TOC entry 2735 (class 2604 OID 17030)
-- Name: casos_por_cidade id; Type: DEFAULT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.casos_por_cidade ALTER COLUMN id SET DEFAULT nextval('coronavirus.casos_por_cidade_id_seq'::regclass);


--
-- TOC entry 2731 (class 2604 OID 16890)
-- Name: cidade id; Type: DEFAULT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.cidade ALTER COLUMN id SET DEFAULT nextval('coronavirus.cidade_id_seq'::regclass);


--
-- TOC entry 2734 (class 2604 OID 16930)
-- Name: covid19_mundo id; Type: DEFAULT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.covid19_mundo ALTER COLUMN id SET DEFAULT nextval('coronavirus.covid19_mundo_id_seq'::regclass);


--
-- TOC entry 2732 (class 2604 OID 16909)
-- Name: leitos id; Type: DEFAULT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.leitos ALTER COLUMN id SET DEFAULT nextval('coronavirus.leitos_id_seq'::regclass);


--
-- TOC entry 2730 (class 2604 OID 16882)
-- Name: temperatura id; Type: DEFAULT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura ALTER COLUMN id SET DEFAULT nextval('coronavirus.temperatura_id_seq'::regclass);


--
-- TOC entry 2736 (class 2604 OID 17078)
-- Name: temperatura_cidade id; Type: DEFAULT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura_cidade ALTER COLUMN id SET DEFAULT nextval('coronavirus.temperatura_cidade_id_seq'::regclass);


--
-- TOC entry 2733 (class 2604 OID 16922)
-- Name: tempo id; Type: DEFAULT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.tempo ALTER COLUMN id SET DEFAULT nextval('coronavirus.tempo_id_seq'::regclass);


--
-- TOC entry 2903 (class 0 OID 17027)
-- Dependencies: 215
-- Data for Name: casos_por_cidade; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.casos_por_cidade (id, id_data, cidade, pais, casos) FROM stdin;
\.


--
-- TOC entry 2894 (class 0 OID 16887)
-- Dependencies: 206
-- Data for Name: cidade; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.cidade (id, nome) FROM stdin;
\.


--
-- TOC entry 2901 (class 0 OID 16927)
-- Dependencies: 213
-- Data for Name: covid19_mundo; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.covid19_mundo (id, data_reg, casos, mortes, pais_cod, total_leitos) FROM stdin;
\.


--
-- TOC entry 2897 (class 0 OID 16906)
-- Dependencies: 209
-- Data for Name: leitos; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.leitos (id, total_leitos, pais_iso) FROM stdin;
\.


--
-- TOC entry 2895 (class 0 OID 16896)
-- Dependencies: 207
-- Data for Name: pais; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.pais (codigo_iso, nome, pop, continente) FROM stdin;
\.


--
-- TOC entry 2892 (class 0 OID 16879)
-- Dependencies: 204
-- Data for Name: temperatura; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.temperatura (id, temp_celsius) FROM stdin;
\.


--
-- TOC entry 2904 (class 0 OID 17048)
-- Dependencies: 216
-- Data for Name: temperatura_cidade; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais, id) FROM stdin;
\.


--
-- TOC entry 2899 (class 0 OID 16919)
-- Dependencies: 211
-- Data for Name: tempo; Type: TABLE DATA; Schema: coronavirus; Owner: postgres
--

COPY coronavirus.tempo (id, dia, mes, ano) FROM stdin;
\.


--
-- TOC entry 2918 (class 0 OID 0)
-- Dependencies: 214
-- Name: casos_por_cidade_id_seq; Type: SEQUENCE SET; Schema: coronavirus; Owner: postgres
--

SELECT pg_catalog.setval('coronavirus.casos_por_cidade_id_seq', 1, false);


--
-- TOC entry 2919 (class 0 OID 0)
-- Dependencies: 205
-- Name: cidade_id_seq; Type: SEQUENCE SET; Schema: coronavirus; Owner: postgres
--

SELECT pg_catalog.setval('coronavirus.cidade_id_seq', 1, false);


--
-- TOC entry 2920 (class 0 OID 0)
-- Dependencies: 212
-- Name: covid19_mundo_id_seq; Type: SEQUENCE SET; Schema: coronavirus; Owner: postgres
--

SELECT pg_catalog.setval('coronavirus.covid19_mundo_id_seq', 1, false);


--
-- TOC entry 2921 (class 0 OID 0)
-- Dependencies: 208
-- Name: leitos_id_seq; Type: SEQUENCE SET; Schema: coronavirus; Owner: postgres
--

SELECT pg_catalog.setval('coronavirus.leitos_id_seq', 1, false);


--
-- TOC entry 2922 (class 0 OID 0)
-- Dependencies: 217
-- Name: temperatura_cidade_id_seq; Type: SEQUENCE SET; Schema: coronavirus; Owner: postgres
--

SELECT pg_catalog.setval('coronavirus.temperatura_cidade_id_seq', 1, false);


--
-- TOC entry 2923 (class 0 OID 0)
-- Dependencies: 203
-- Name: temperatura_id_seq; Type: SEQUENCE SET; Schema: coronavirus; Owner: postgres
--

SELECT pg_catalog.setval('coronavirus.temperatura_id_seq', 1, false);


--
-- TOC entry 2924 (class 0 OID 0)
-- Dependencies: 210
-- Name: tempo_id_seq; Type: SEQUENCE SET; Schema: coronavirus; Owner: postgres
--

SELECT pg_catalog.setval('coronavirus.tempo_id_seq', 1, false);


--
-- TOC entry 2750 (class 2606 OID 17032)
-- Name: casos_por_cidade casos_por_cidade_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.casos_por_cidade
    ADD CONSTRAINT casos_por_cidade_pkey PRIMARY KEY (id);


--
-- TOC entry 2740 (class 2606 OID 16895)
-- Name: cidade cidade_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.cidade
    ADD CONSTRAINT cidade_pkey PRIMARY KEY (id);


--
-- TOC entry 2748 (class 2606 OID 16932)
-- Name: covid19_mundo covid19_mundo_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.covid19_mundo
    ADD CONSTRAINT covid19_mundo_pkey PRIMARY KEY (id);


--
-- TOC entry 2744 (class 2606 OID 16911)
-- Name: leitos leitos_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.leitos
    ADD CONSTRAINT leitos_pkey PRIMARY KEY (id);


--
-- TOC entry 2742 (class 2606 OID 16903)
-- Name: pais pais_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.pais
    ADD CONSTRAINT pais_pkey PRIMARY KEY (codigo_iso);


--
-- TOC entry 2752 (class 2606 OID 17083)
-- Name: temperatura_cidade temperatura_cidade_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura_cidade
    ADD CONSTRAINT temperatura_cidade_pkey PRIMARY KEY (id);


--
-- TOC entry 2738 (class 2606 OID 16884)
-- Name: temperatura temperatura_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura
    ADD CONSTRAINT temperatura_pkey PRIMARY KEY (id);


--
-- TOC entry 2746 (class 2606 OID 16924)
-- Name: tempo tempo_pkey; Type: CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.tempo
    ADD CONSTRAINT tempo_pkey PRIMARY KEY (id);


--
-- TOC entry 2757 (class 2606 OID 17033)
-- Name: casos_por_cidade cidade_casos_cidade_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.casos_por_cidade
    ADD CONSTRAINT cidade_casos_cidade_fk FOREIGN KEY (cidade) REFERENCES coronavirus.cidade(id);


--
-- TOC entry 2760 (class 2606 OID 17051)
-- Name: temperatura_cidade cidade_temp_cidade_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura_cidade
    ADD CONSTRAINT cidade_temp_cidade_fk FOREIGN KEY (cidade) REFERENCES coronavirus.cidade(id);


--
-- TOC entry 2759 (class 2606 OID 17043)
-- Name: casos_por_cidade data_id_casos_cidade_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.casos_por_cidade
    ADD CONSTRAINT data_id_casos_cidade_fk FOREIGN KEY (id_data) REFERENCES coronavirus.tempo(id);


--
-- TOC entry 2762 (class 2606 OID 17061)
-- Name: temperatura_cidade data_id_temp_cidade_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura_cidade
    ADD CONSTRAINT data_id_temp_cidade_fk FOREIGN KEY (id_data) REFERENCES coronavirus.tempo(id);


--
-- TOC entry 2756 (class 2606 OID 16943)
-- Name: covid19_mundo leitos_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.covid19_mundo
    ADD CONSTRAINT leitos_fk FOREIGN KEY (total_leitos) REFERENCES coronavirus.leitos(id);


--
-- TOC entry 2758 (class 2606 OID 17038)
-- Name: casos_por_cidade pais_casos_cidade_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.casos_por_cidade
    ADD CONSTRAINT pais_casos_cidade_fk FOREIGN KEY (pais) REFERENCES coronavirus.pais(codigo_iso);


--
-- TOC entry 2753 (class 2606 OID 16912)
-- Name: leitos pais_codfk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.leitos
    ADD CONSTRAINT pais_codfk FOREIGN KEY (pais_iso) REFERENCES coronavirus.pais(codigo_iso);


--
-- TOC entry 2755 (class 2606 OID 16938)
-- Name: covid19_mundo pais_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.covid19_mundo
    ADD CONSTRAINT pais_fk FOREIGN KEY (pais_cod) REFERENCES coronavirus.pais(codigo_iso);


--
-- TOC entry 2761 (class 2606 OID 17056)
-- Name: temperatura_cidade pais_temp_cidade_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura_cidade
    ADD CONSTRAINT pais_temp_cidade_fk FOREIGN KEY (pais) REFERENCES coronavirus.pais(codigo_iso);


--
-- TOC entry 2763 (class 2606 OID 17066)
-- Name: temperatura_cidade temp_max_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura_cidade
    ADD CONSTRAINT temp_max_fk FOREIGN KEY (temp_max) REFERENCES coronavirus.temperatura(id);


--
-- TOC entry 2764 (class 2606 OID 17071)
-- Name: temperatura_cidade temp_min_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.temperatura_cidade
    ADD CONSTRAINT temp_min_fk FOREIGN KEY (temp_min) REFERENCES coronavirus.temperatura(id);


--
-- TOC entry 2754 (class 2606 OID 16933)
-- Name: covid19_mundo tempo_fk; Type: FK CONSTRAINT; Schema: coronavirus; Owner: postgres
--

ALTER TABLE ONLY coronavirus.covid19_mundo
    ADD CONSTRAINT tempo_fk FOREIGN KEY (data_reg) REFERENCES coronavirus.tempo(id);


-- Completed on 2020-05-27 18:39:48

--
-- PostgreSQL database dump complete
--

