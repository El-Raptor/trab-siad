INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=02 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=02 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=02 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	1);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=02 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=01 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	2);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	3);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	6);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	10);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	12);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	15);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	15);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	18);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	29);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	44);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	55);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	62);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	133);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	145);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	156);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	214);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	282);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	358);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	396);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	442);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	477);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	484);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	537);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	565);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	565);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	565);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	565);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	593);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=03 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	1438);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=01 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	1503);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=02 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	1520);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=03 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	2321);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=04 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	2729);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=05 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	3612);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=06 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	3754);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=07 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	4503);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=08 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	5137);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=09 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	5832);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	6379);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	6585);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	6805);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	6831);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	6993);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	8024);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	8889);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	9357);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	10127);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	10388);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	10624);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	11265);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	11383);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	11025);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	12202);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	14279);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	13979);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	14104);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=04 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='São Paulo' ),
	'BRA',
	15213);
