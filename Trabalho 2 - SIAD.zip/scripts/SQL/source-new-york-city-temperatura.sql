INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=-4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=14),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=15),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=13),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=3),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=2),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=15),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=2),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=22),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=8),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=18),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=12),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=14),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=6),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=10),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=6),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=21),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=14),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=6),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=12),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=1),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=12),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=5),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=12),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=5),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=5),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=25),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=8),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=18),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=1),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=5),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=2),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=13),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=2),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=16),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=3),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=21),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=10),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=12),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=17),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=8),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=5),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=5),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=13),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=3),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=14),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=17),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=8),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=18),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=8),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=19),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=20),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=18),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=15),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=6),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=3),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=13),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=3),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=17),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=19),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=12),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=16),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=8),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=12),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=6),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=10),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=3),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=2),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=8),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=5),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=17),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=14),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=16),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=2),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=9),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=6),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=18),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=7),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=11),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=6),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
INSERT INTO coronavirus.temperatura_cidade (id_data, temp_max, temp_min, cidade, pais) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=10),
	(SELECT id from coronavirus.temperatura WHERE temp_celsius=4),
	(SELECT id from coronavirus.cidade WHERE nome='New York City'),
	 'USA');
