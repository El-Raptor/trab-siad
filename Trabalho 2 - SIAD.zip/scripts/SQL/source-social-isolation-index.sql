INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=2 AND ano=2020),24.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=2 AND ano=2020),27.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=2 AND ano=2020),26.6);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=2 AND ano=2020),31.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=3 AND ano=2020),42);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=3 AND ano=2020),27.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=3 AND ano=2020),29);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=3 AND ano=2020),30.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=3 AND ano=2020),29.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=3 AND ano=2020),28.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=3 AND ano=2020),31.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=3 AND ano=2020),41);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=3 AND ano=2020),29.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=3 AND ano=2020),29.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=3 AND ano=2020),28.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=3 AND ano=2020),30.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=3 AND ano=2020),30.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=3 AND ano=2020),35.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=3 AND ano=2020),42.6);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=3 AND ano=2020),32.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=3 AND ano=2020),32.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=3 AND ano=2020),36);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=3 AND ano=2020),39.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=3 AND ano=2020),40.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=3 AND ano=2020),52.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=3 AND ano=2020),62.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=3 AND ano=2020),52.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=3 AND ano=2020),53.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=3 AND ano=2020),53.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=3 AND ano=2020),53.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=3 AND ano=2020),51.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=3 AND ano=2020),53.9);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=3 AND ano=2020),59.9);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=3 AND ano=2020),49.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=3 AND ano=2020),48.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=4 AND ano=2020),46);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=4 AND ano=2020),48.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=4 AND ano=2020),47.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=4 AND ano=2020),50.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=4 AND ano=2020),56.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=4 AND ano=2020),47.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=4 AND ano=2020),45.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=4 AND ano=2020),45);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=4 AND ano=2020),44.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=4 AND ano=2020),54.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=4 AND ano=2020),48);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=4 AND ano=2020),54);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=4 AND ano=2020),46.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=4 AND ano=2020),46);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=4 AND ano=2020),45.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=4 AND ano=2020),42.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=4 AND ano=2020),43);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=4 AND ano=2020),46.6);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=4 AND ano=2020),54.6);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=4 AND ano=2020),45.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=4 AND ano=2020),52.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=4 AND ano=2020),43.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=4 AND ano=2020),44.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=4 AND ano=2020),42.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=4 AND ano=2020),46);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=4 AND ano=2020),53.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=4 AND ano=2020),44.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=4 AND ano=2020),43.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=4 AND ano=2020),42.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=4 AND ano=2020),41.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=5 AND ano=2020),49.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=5 AND ano=2020),44);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=5 AND ano=2020),50);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=5 AND ano=2020),43.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=5 AND ano=2020),42.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=5 AND ano=2020),47.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=5 AND ano=2020),43.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=5 AND ano=2020),40.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=5 AND ano=2020),43.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=5 AND ano=2020),47);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=5 AND ano=2020),43.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=5 AND ano=2020),43.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=5 AND ano=2020),43.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=5 AND ano=2020),43);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=5 AND ano=2020),42.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=5 AND ano=2020),45.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=5 AND ano=2020),52.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=5 AND ano=2020),42.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=5 AND ano=2020),42.4);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=5 AND ano=2020),41.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=5 AND ano=2020),42.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=5 AND ano=2020),41.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=5 AND ano=2020),45.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=5 AND ano=2020),53.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=5 AND ano=2020),43.9);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=5 AND ano=2020),41.6);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=5 AND ano=2020),41.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=5 AND ano=2020),41.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=5 AND ano=2020),39.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=5 AND ano=2020),42.6);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=5 AND ano=2020),49.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=6 AND ano=2020),40.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=6 AND ano=2020),40.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=6 AND ano=2020),39.5);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=6 AND ano=2020),39.1);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=6 AND ano=2020),39.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=6 AND ano=2020),40.6);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=6 AND ano=2020),48.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=6 AND ano=2020),38.2);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=6 AND ano=2020),38);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=6 AND ano=2020),39.3);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=6 AND ano=2020),43.7);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=6 AND ano=2020),36.8);
INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=6 AND ano=2020),40.1);


INSERT INTO coronavirus.indice_isolamento_social  (data_reg, taxa_isolamento) VALUES (
	
	(SELECT id from coronavirus.tempo WHERE dia=14 AND mes=6 AND ano=2020),
	48.38
);

INSERT INTO coronavirus.indice_isolamento_social  (data_reg, taxa_isolamento) VALUES (
	
	(SELECT id from coronavirus.tempo WHERE dia=15 AND mes=6 AND ano=2020),
	39.33
);

INSERT INTO coronavirus.indice_isolamento_social  (data_reg, taxa_isolamento) VALUES (
	
	(SELECT id from coronavirus.tempo WHERE dia=16 AND mes=6 AND ano=2020),
	39.56
);

INSERT INTO coronavirus.indice_isolamento_social  (data_reg, taxa_isolamento) VALUES (
	
	(SELECT id from coronavirus.tempo WHERE dia=17 AND mes=6 AND ano=2020),
	37.75
);

INSERT INTO coronavirus.indice_isolamento_social  (data_reg, taxa_isolamento) VALUES (
	
	(SELECT id from coronavirus.tempo WHERE dia=18 AND mes=6 AND ano=2020),
	39.01
);

INSERT INTO coronavirus.indice_isolamento_social  (data_reg, taxa_isolamento) VALUES (
	
	(SELECT id from coronavirus.tempo WHERE dia=19 AND mes=6 AND ano=2020),
	35.02
);

INSERT INTO coronavirus.indice_isolamento_social  (data_reg, taxa_isolamento) VALUES (
	
	(SELECT id from coronavirus.tempo WHERE dia=20 AND mes=6 AND ano=2020),
	39,.37
);

INSERT INTO coronavirus.indice_isolamento_social  ( data_reg, taxa_isolamento) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=6 AND ano=2020),47.3);