INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	0);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=2 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	6);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	6);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	7);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	14);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	29);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	42);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	49);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	71);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	77);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	91);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	76);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	99);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	162);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	218);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	288);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	354);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	412);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	486);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	590);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	678);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	755);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	893);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1049);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1171);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1287);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1428);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1567);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1703);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1839);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=29 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	1945);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=30 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2068);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=31 AND mes=3 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2186);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=1 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2260);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=2 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2393);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=3 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2503);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=4 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2620);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=5 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2714);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=6 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2769);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=7 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2830);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=8 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	2910);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=9 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3026);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=10 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3114);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=11 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3219);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=12 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3315);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=13 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3431);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=14 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3560);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=15 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3665);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=16 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3767);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=17 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	3888);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=18 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4018);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=19 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4082);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=20 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4133);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=21 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4189);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=22 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4257);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=23 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4313);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=24 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4361);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=25 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4434);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=26 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4501);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=27 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4569);
INSERT INTO coronavirus.casos_por_cidade (id_data, cidade, pais, casos) VALUES
	((SELECT id from coronavirus.tempo WHERE dia=28 AND mes=4 AND ano=2020),
	(SELECT id from coronavirus.cidade WHERE nome='Roma' ),
	'ITA',
	4642);
